// Axios API configuration placeholder
