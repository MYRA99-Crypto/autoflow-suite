# AutoFlow Suite
This is a full-stack automation dashboard using React & FastAPI.